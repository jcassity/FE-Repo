14:03 2022/02/10
Hello, thank you for your interest.
I would like to describe a bug or glitch.
---------------------------------------------------------------------------------------------------------------
For use with FE6:
We have found a mysterious bug in the CSA of FE6, so it is not recommended.
The confirmed mysterious bug is listed below.

1. Regardless of the unit, when I destroy an enemy with a CSA animation, 
   half the screen goes black for a second (but it didn't freeze). 
  *However, this did not happen with enemy units that had death quote.
   ↓↓↓↓↓↓↓↓↓↓↓↓↓↓

   https://youtu.be/ET4UUfQMfHs

2. Only Ivaldi's animations freeze when my units finish off the battle of Idunn in FE6 with a follow-up attack.
   Probably the reason is that only in the battle against Idunn, 
   the CSA continues to work even after the HP number reaches 0. 
   However, if the CSA animation ends first before the HP number reaches 0, the game does not freeze.
  *I also tested it with other transformation classes such as Jahn, 
   and it worked fine, so it seems that it only freezes against Idunn.
   ↓↓↓↓↓↓↓↓↓↓↓↓↓↓

   https://youtu.be/QWluEzanM3U

---------------------------------------------------------------------------------------------------------------
For use with FE7:
1. For FE7 USA version, please use CSA_Creator. 
   Otherwise, the USA version of FEditor will glitch and mess up the palette. 
  *However, the JPN version does not have a problem with either.
2. In FE7, the data for the Gleipnir sound effects 3AC and 3AD are filled with existing environmental sounds, 
   so you will have to port them to another free data and rewrite them yourself to make them work. 
  *Incidentally, the sample patch uses 3AD and 3B2.
---------------------------------------------------------------------------------------------------------------

Credits: SHYUTERz